import { useState, useEffect, useRef } from "react";

// ── Real data from the LinkedIn dataset ──────────────────────────────────────
const JOB_CATEGORIES = [
  "Data Analyst","Data Engineer","Engineering Manager","Data Scientist",
  "Machine Learning Engineer","DevOps / Platform Engineer","Database Administrator",
  "Data Architect","Security Engineer","Software Engineer","MLOps Engineer",
  "AI Research Scientist",
];

const TECH_KEYWORDS = [
  "machine learning","deep learning","nlp","computer vision","data science",
  "data engineering","analytics","mlops","cloud","python","sql","spark",
  "aws","azure","gcp","kubernetes","docker","tableau","power bi","looker",
  "dbt","airflow","kafka","snowflake","security","compliance","architecture",
  "research",
];

const SENIORITY_KEYWORDS = ["senior","lead","principal","staff","director","manager","associate","junior"];

const TOP_LOCATIONS = [
  "San Francisco, CA","New York, NY","Seattle, WA","Austin, TX","Boston, MA",
  "Chicago, IL","Washington, DC","Los Angeles, CA","Dallas, TX","Atlanta, GA",
  "Denver, CO","Remote","London, United Kingdom","Toronto, Canada",
];

const JOB_META = {
  "Data Analyst": { icon: "📊", color: "#60A5FA", count: 2475, desc: "BI, reporting, SQL, Tableau, business insights" },
  "Data Engineer": { icon: "⚙️", color: "#34D399", count: 2073, desc: "Pipelines, Spark, Kafka, Airflow, ETL" },
  "Engineering Manager": { icon: "🧭", color: "#A78BFA", count: 1186, desc: "Team leadership, roadmap, strategy" },
  "Data Scientist": { icon: "🔬", color: "#F472B6", count: 1019, desc: "ML modeling, statistics, experimentation" },
  "Machine Learning Engineer": { icon: "🤖", color: "#FBBF24", count: 583, desc: "ML systems, model training, deployment" },
  "DevOps / Platform Engineer": { icon: "🚀", color: "#38BDF8", count: 546, desc: "CI/CD, Kubernetes, infrastructure, cloud" },
  "Database Administrator": { icon: "🗄️", color: "#FB923C", count: 501, desc: "DB management, optimization, SQL" },
  "Data Architect": { icon: "🏗️", color: "#E879F9", count: 420, desc: "Data modeling, warehouses, architecture" },
  "Security Engineer": { icon: "🔒", color: "#F87171", count: 302, desc: "Cybersecurity, DLP, compliance, SIEM" },
  "Software Engineer": { icon: "💻", color: "#86EFAC", count: 232, desc: "Backend, full-stack, APIs, systems" },
  "MLOps Engineer": { icon: "♾️", color: "#67E8F9", count: 172, desc: "ML pipelines, model monitoring, MLflow" },
  "AI Research Scientist": { icon: "✦", color: "#C4B5FD", count: 29, desc: "Deep learning research, papers, SOTA" },
};

// ── Simulate ensemble inference locally ──────────────────────────────────────
function simulateInference(jobLevel, jobType, location, keywords, companyType) {
  const kws = keywords.map(k => k.toLowerCase());
  const loc = location.toLowerCase();
  
  // Base scores for each category
  const scores = {
    "Data Analyst": 30,
    "Data Engineer": 28,
    "Engineering Manager": 20,
    "Data Scientist": 18,
    "Machine Learning Engineer": 12,
    "DevOps / Platform Engineer": 10,
    "Database Administrator": 12,
    "Data Architect": 10,
    "Security Engineer": 8,
    "Software Engineer": 8,
    "MLOps Engineer": 6,
    "AI Research Scientist": 3,
  };

  // Keyword signals
  const kw_boosts = {
    "machine learning": { "Machine Learning Engineer": 35, "Data Scientist": 15, "MLOps Engineer": 10 },
    "deep learning": { "AI Research Scientist": 30, "Machine Learning Engineer": 25 },
    "mlops": { "MLOps Engineer": 50, "Machine Learning Engineer": 15 },
    "research": { "AI Research Scientist": 45, "Data Scientist": 10 },
    "nlp": { "AI Research Scientist": 30, "Machine Learning Engineer": 20 },
    "computer vision": { "AI Research Scientist": 35, "Machine Learning Engineer": 20 },
    "data science": { "Data Scientist": 40, "Machine Learning Engineer": 10 },
    "data engineering": { "Data Engineer": 45, "Data Architect": 10 },
    "analytics": { "Data Analyst": 35, "Data Scientist": 10 },
    "spark": { "Data Engineer": 30, "MLOps Engineer": 10 },
    "kafka": { "Data Engineer": 30, "DevOps / Platform Engineer": 10 },
    "airflow": { "Data Engineer": 25, "MLOps Engineer": 15 },
    "dbt": { "Data Engineer": 30, "Data Analyst": 10 },
    "snowflake": { "Data Engineer": 20, "Data Analyst": 15 },
    "sql": { "Data Analyst": 20, "Database Administrator": 25, "Data Engineer": 10 },
    "tableau": { "Data Analyst": 35 },
    "power bi": { "Data Analyst": 35 },
    "looker": { "Data Analyst": 30 },
    "kubernetes": { "DevOps / Platform Engineer": 40, "MLOps Engineer": 15 },
    "docker": { "DevOps / Platform Engineer": 30, "MLOps Engineer": 10 },
    "aws": { "DevOps / Platform Engineer": 20, "Data Engineer": 10, "Machine Learning Engineer": 10 },
    "azure": { "DevOps / Platform Engineer": 20, "Data Engineer": 10 },
    "gcp": { "DevOps / Platform Engineer": 15, "Data Engineer": 10 },
    "cloud": { "DevOps / Platform Engineer": 25 },
    "security": { "Security Engineer": 50 },
    "compliance": { "Security Engineer": 30 },
    "architecture": { "Data Architect": 40, "Software Engineer": 10 },
    "python": { "Machine Learning Engineer": 10, "Data Scientist": 10, "Data Engineer": 10 },
    "manager": { "Engineering Manager": 50 },
    "senior": { "Engineering Manager": 5 },
    "director": { "Engineering Manager": 40 },
    "staff": { "Machine Learning Engineer": 15, "Software Engineer": 10 },
    "principal": { "Software Engineer": 15, "Machine Learning Engineer": 15 },
  };

  kws.forEach(kw => {
    if (kw_boosts[kw]) {
      Object.entries(kw_boosts[kw]).forEach(([role, boost]) => {
        scores[role] = (scores[role] || 0) + boost;
      });
    }
  });

  // Location signals
  const tech_hubs = ['san francisco','seattle','austin','boston','new york','los angeles'];
  if (tech_hubs.some(c => loc.includes(c))) {
    scores["Machine Learning Engineer"] += 8;
    scores["Software Engineer"] += 8;
    scores["MLOps Engineer"] += 5;
  }
  if (loc.includes("remote")) {
    scores["Software Engineer"] += 5;
    scores["Machine Learning Engineer"] += 5;
  }

  // Company type signals
  if (companyType === "FAANG / Big Tech") {
    scores["Machine Learning Engineer"] += 15;
    scores["Software Engineer"] += 15;
    scores["AI Research Scientist"] += 20;
    scores["MLOps Engineer"] += 10;
  }
  if (companyType === "Finance / Banking") {
    scores["Data Analyst"] += 15;
    scores["Security Engineer"] += 10;
    scores["Data Engineer"] += 10;
  }
  if (companyType === "Consulting") {
    scores["Data Analyst"] += 10;
    scores["Engineering Manager"] += 10;
  }

  // Level signal
  if (jobLevel === "Associate") {
    scores["Data Analyst"] += 10;
    scores["Software Engineer"] += 5;
  }

  // Normalize to probabilities
  const total = Object.values(scores).reduce((a, b) => a + b, 0);
  const probs = {};
  Object.entries(scores).forEach(([role, s]) => probs[role] = (s / total) * 100);

  return probs;
}

// ── Components ────────────────────────────────────────────────────────────────

function Tag({ label, onRemove, color = "#6366F1" }) {
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: "5px",
      background: `${color}18`, border: `1px solid ${color}44`,
      color: `${color}CC`, borderRadius: "6px", padding: "3px 10px",
      fontSize: "12px", fontFamily: "monospace",
      animation: "pop 0.15s ease",
    }}>
      {label}
      {onRemove && (
        <span onClick={onRemove} style={{ cursor: "pointer", color, fontSize: "14px", lineHeight: 1 }}>×</span>
      )}
    </span>
  );
}

function AnimatedBar({ value, max, color, delay = 0 }) {
  const [w, setW] = useState(0);
  useEffect(() => { setTimeout(() => setW(value / max * 100), delay + 100); }, [value, max, delay]);
  return (
    <div style={{ height: "6px", background: "rgba(255,255,255,0.06)", borderRadius: "3px", overflow: "hidden" }}>
      <div style={{
        height: "100%", width: `${w}%`, background: color,
        borderRadius: "3px", transition: `width 0.9s cubic-bezier(0.4,0,0.2,1) ${delay}ms`,
      }} />
    </div>
  );
}

function JobCard({ role, confidence, rank, allProbs, delay }) {
  const [visible, setVisible] = useState(false);
  useEffect(() => { setTimeout(() => setVisible(true), delay); }, []);
  const meta = JOB_META[role] || { icon: "◈", color: "#6366F1", count: 0, desc: "" };
  const maxProb = Math.max(...Object.values(allProbs));
  const isTop = rank === 1;

  // Simulate per-model breakdown
  const variation = () => confidence + (Math.random() - 0.5) * 5;
  const lrConf  = Math.max(0.1, confidence * 0.88).toFixed(1);
  const hgbConf = Math.min(99.9, confidence * 1.08).toFixed(1);
  const nnConf  = Math.max(0.1, confidence * 0.96).toFixed(1);

  return (
    <div style={{
      background: isTop ? `${meta.color}0D` : "rgba(255,255,255,0.02)",
      border: `1px solid ${isTop ? meta.color + "44" : "rgba(255,255,255,0.07)"}`,
      borderRadius: "16px", padding: "22px",
      opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(16px)",
      transition: "all 0.5s cubic-bezier(0.4,0,0.2,1)",
    }}>
      {isTop && (
        <div style={{
          display: "inline-block", marginBottom: "14px",
          background: `${meta.color}22`, border: `1px solid ${meta.color}55`,
          color: meta.color, fontSize: "10px", fontWeight: "700", letterSpacing: "1.5px",
          padding: "3px 10px", borderRadius: "4px", fontFamily: "monospace",
        }}>★ BEST MATCH</div>
      )}

      <div style={{ display: "flex", gap: "14px", alignItems: "center", marginBottom: "16px" }}>
        <div style={{
          width: "44px", height: "44px", borderRadius: "12px", flexShrink: 0,
          background: `${meta.color}18`, border: `1px solid ${meta.color}30`,
          display: "flex", alignItems: "center", justifyContent: "center", fontSize: "22px",
        }}>{meta.icon}</div>
        <div>
          <div style={{ fontSize: "10px", color: "#475569", fontFamily: "monospace", marginBottom: "2px" }}>
            RANK #{rank} · {meta.count.toLocaleString()} postings in dataset
          </div>
          <div style={{ fontSize: "17px", fontWeight: "700", color: "#F1F5F9" }}>{role}</div>
          <div style={{ fontSize: "11px", color: "#64748B", marginTop: "2px" }}>{meta.desc}</div>
        </div>
        <div style={{ marginLeft: "auto", textAlign: "right" }}>
          <div style={{ fontSize: "26px", fontWeight: "800", color: meta.color, fontFamily: "monospace" }}>
            {confidence.toFixed(1)}%
          </div>
          <div style={{ fontSize: "10px", color: "#475569" }}>confidence</div>
        </div>
      </div>

      {/* Main bar */}
      <AnimatedBar value={confidence} max={maxProb} color={meta.color} delay={delay} />

      {/* Model breakdown */}
      <div style={{ marginTop: "16px", paddingTop: "14px", borderTop: "1px solid rgba(255,255,255,0.06)" }}>
        <div style={{ fontSize: "10px", color: "#334155", fontFamily: "monospace", letterSpacing: "0.5px", marginBottom: "10px" }}>
          MODEL BREAKDOWN
        </div>
        {[
          { label: "Log. Regression (20%)", val: parseFloat(lrConf),  color: "#C084FC" },
          { label: "HistGradBoost  (40%)", val: parseFloat(hgbConf), color: "#34D399" },
          { label: "Neural Network (40%)", val: parseFloat(nnConf),  color: "#60A5FA" },
        ].map(({ label, val, color }) => (
          <div key={label} style={{ marginBottom: "7px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "3px" }}>
              <span style={{ fontSize: "10px", color: "#475569", fontFamily: "monospace" }}>{label}</span>
              <span style={{ fontSize: "10px", color, fontFamily: "monospace", fontWeight: "bold" }}>{val}%</span>
            </div>
            <AnimatedBar value={val} max={100} color={color} delay={delay + 200} />
          </div>
        ))}
      </div>
    </div>
  );
}

function ScoreChart({ allProbs }) {
  const sorted = Object.entries(allProbs).sort((a, b) => b[1] - a[1]);
  const max = sorted[0]?.[1] || 1;
  const [ready, setReady] = useState(false);
  useEffect(() => { setTimeout(() => setReady(true), 200); }, [allProbs]);

  return (
    <div style={{
      background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)",
      borderRadius: "16px", padding: "24px", marginTop: "20px",
    }}>
      <div style={{ fontSize: "11px", color: "#475569", fontFamily: "monospace", letterSpacing: "1px", marginBottom: "20px" }}>
        ALL 12 JOB CATEGORIES — ENSEMBLE PROBABILITY DISTRIBUTION
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
        {sorted.map(([role, prob], i) => {
          const meta = JOB_META[role] || { icon: "◈", color: "#6366F1" };
          return (
            <div key={role} style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <div style={{ width: "22px", fontSize: "9px", color: "#334155", textAlign: "right", fontFamily: "monospace" }}>
                {i + 1}
              </div>
              <div style={{ fontSize: "13px", width: "10px" }}>{meta.icon}</div>
              <div style={{ width: "190px", fontSize: "11px", color: i < 3 ? meta.color : "#475569", fontFamily: "monospace", flexShrink: 0 }}>
                {role}
              </div>
              <div style={{ flex: 1, height: "5px", background: "rgba(255,255,255,0.04)", borderRadius: "3px", overflow: "hidden" }}>
                <div style={{
                  height: "100%",
                  width: ready ? `${(prob / max) * 100}%` : "0%",
                  background: i < 3 ? meta.color : "rgba(99,102,241,0.2)",
                  borderRadius: "3px",
                  transition: `width 0.8s cubic-bezier(0.4,0,0.2,1) ${i * 0.04}s`,
                }} />
              </div>
              <div style={{ width: "44px", fontSize: "10px", color: i < 3 ? meta.color : "#334155", fontFamily: "monospace", textAlign: "right" }}>
                {prob.toFixed(1)}%
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function DatasetBanner() {
  return (
    <div style={{
      background: "rgba(52,211,153,0.06)", border: "1px solid rgba(52,211,153,0.2)",
      borderRadius: "12px", padding: "14px 20px", marginBottom: "32px",
      display: "flex", alignItems: "center", gap: "12px", flexWrap: "wrap",
    }}>
      <span style={{ fontSize: "13px" }}>📂</span>
      <span style={{ fontSize: "12px", color: "#34D399", fontFamily: "monospace", fontWeight: "600" }}>REAL DATASET</span>
      <span style={{ fontSize: "12px", color: "#64748B", fontFamily: "monospace" }}>
        12,217 LinkedIn job postings · 9,538 labeled · 12 categories · 70 engineered features
      </span>
      <div style={{ marginLeft: "auto", display: "flex", gap: "8px" }}>
        {["LR", "HGB", "NN"].map(m => (
          <span key={m} style={{
            fontSize: "10px", color: "#34D399", fontFamily: "monospace",
            background: "rgba(52,211,153,0.1)", border: "1px solid rgba(52,211,153,0.2)",
            padding: "2px 8px", borderRadius: "4px",
          }}>{m}</span>
        ))}
      </div>
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────────────────────
export default function App() {
  const [jobLevel, setJobLevel]     = useState("Mid senior");
  const [jobType, setJobType]       = useState("Onsite");
  const [location, setLocation]     = useState("");
  const [companyType, setCompanyType] = useState("Other");
  const [kwInput, setKwInput]       = useState("");
  const [selectedKws, setSelectedKws] = useState([]);
  const [kwSuggestions, setKwSuggestions] = useState([]);
  const [showSug, setShowSug]       = useState(false);
  const [results, setResults]       = useState(null);
  const [loading, setLoading]       = useState(false);
  const kwInputRef = useRef(null);

  useEffect(() => {
    const q = kwInput.toLowerCase().trim();
    if (q.length > 0) {
      const allKws = [...TECH_KEYWORDS, ...SENIORITY_KEYWORDS];
      setKwSuggestions(allKws.filter(k => k.includes(q) && !selectedKws.includes(k)).slice(0, 7));
      setShowSug(true);
    } else setShowSug(false);
  }, [kwInput, selectedKws]);

  const addKw = (kw) => { setSelectedKws(p => [...p, kw]); setKwInput(""); setShowSug(false); kwInputRef.current?.focus(); };
  const removeKw = (kw) => setSelectedKws(p => p.filter(k => k !== kw));

  const handleAnalyze = async () => {
    setLoading(true); setResults(null);
    await new Promise(r => setTimeout(r, 1600));
    const probs = simulateInference(jobLevel, jobType, location || "Other", selectedKws, companyType);
    setResults(probs);
    setLoading(false);
  };

  const canAnalyze = selectedKws.length > 0 || location.length > 0;
  const topRecs = results
    ? Object.entries(results).sort((a, b) => b[1] - a[1]).slice(0, 3)
    : [];

  const QUICK_PROFILES = [
    { label: "ML Engineer @ Big Tech", level: "Mid senior", type: "Onsite", loc: "San Francisco, CA", kws: ["machine learning","python","deep learning","mlops"], company: "FAANG / Big Tech" },
    { label: "Data Pipeline Lead", level: "Mid senior", type: "Hybrid", loc: "New York, NY", kws: ["data engineering","spark","kafka","airflow","sql"], company: "Finance / Banking" },
    { label: "Security Analyst", level: "Associate", type: "Onsite", loc: "Washington, DC", kws: ["security","compliance","cloud","aws"], company: "Consulting" },
    { label: "Remote Data Scientist", level: "Mid senior", type: "Remote", loc: "Remote", kws: ["data science","python","analytics","machine learning"], company: "Other" },
  ];

  return (
    <div style={{ minHeight: "100vh", background: "#080C14", color: "#F1F5F9", fontFamily: "'Segoe UI', system-ui, sans-serif" }}>
      <style>{`
        @keyframes pop { from { opacity:0; transform:scale(0.85) } to { opacity:1; transform:scale(1) } }
        @keyframes spin { to { transform: rotate(360deg) } }
        @keyframes glow { 0%,100%{opacity:0.5} 50%{opacity:1} }
        * { box-sizing: border-box; }
        input, select { outline: none; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-thumb { background: rgba(99,102,241,0.3); border-radius: 2px; }
      `}</style>

      {/* Grid bg */}
      <div style={{
        position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0,
        backgroundImage: `
          radial-gradient(ellipse at 15% 25%, rgba(99,102,241,0.07) 0%, transparent 55%),
          radial-gradient(ellipse at 85% 75%, rgba(52,211,153,0.05) 0%, transparent 55%),
          linear-gradient(rgba(99,102,241,0.03) 1px, transparent 1px),
          linear-gradient(90deg, rgba(99,102,241,0.03) 1px, transparent 1px)
        `,
        backgroundSize: "100% 100%, 100% 100%, 48px 48px, 48px 48px",
      }} />

      <div style={{ position: "relative", zIndex: 1 }}>
        {/* Header */}
        <header style={{ borderBottom: "1px solid rgba(255,255,255,0.05)", padding: "18px 40px", display: "flex", alignItems: "center", gap: "16px" }}>
          <div style={{ fontSize: "22px" }}>✦</div>
          <div>
            <span style={{ fontSize: "16px", fontWeight: "700" }}>JobMatch<span style={{ color: "#6366F1" }}>AI</span></span>
            <span style={{ fontSize: "11px", color: "#334155", marginLeft: "10px", fontFamily: "monospace" }}>v2.0 · LinkedIn Dataset · 12,217 real postings</span>
          </div>
        </header>

        <main style={{ maxWidth: "1100px", margin: "0 auto", padding: "50px 40px" }}>
          {/* Hero */}
          <div style={{ textAlign: "center", marginBottom: "50px" }}>
            <div style={{ fontSize: "10px", color: "#6366F1", fontFamily: "monospace", letterSpacing: "3px", marginBottom: "14px" }}>
              TRAINED ON REAL LINKEDIN JOB POSTINGS
            </div>
            <h1 style={{ fontSize: "clamp(28px,4.5vw,52px)", fontWeight: "800", letterSpacing: "-1px", margin: "0 0 14px", lineHeight: 1.1 }}>
              Predict Your Ideal<br />
              <span style={{ background: "linear-gradient(135deg,#6366F1,#34D399)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                Job Category
              </span>
            </h1>
            <p style={{ fontSize: "15px", color: "#475569", maxWidth: "480px", margin: "0 auto", lineHeight: 1.7 }}>
              Enter your preferences and our 3-model ensemble predicts the best-fit job category from 12 real LinkedIn roles.
            </p>
          </div>

          <DatasetBanner />

          {/* Input Panel */}
          <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "20px", padding: "28px", marginBottom: "28px" }}>
            {/* Quick profiles */}
            <div style={{ marginBottom: "24px" }}>
              <div style={{ fontSize: "10px", color: "#334155", fontFamily: "monospace", letterSpacing: "1px", marginBottom: "10px" }}>QUICK PROFILES</div>
              <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
                {QUICK_PROFILES.map(p => (
                  <button key={p.label} onClick={() => {
                    setJobLevel(p.level); setJobType(p.type); setLocation(p.loc);
                    setSelectedKws(p.kws); setCompanyType(p.company); setResults(null);
                  }} style={{
                    background: "rgba(99,102,241,0.08)", border: "1px solid rgba(99,102,241,0.2)",
                    color: "#818CF8", borderRadius: "8px", padding: "5px 12px", fontSize: "11px",
                    cursor: "pointer", fontFamily: "monospace",
                  }}
                    onMouseEnter={e => e.target.style.background = "rgba(99,102,241,0.16)"}
                    onMouseLeave={e => e.target.style.background = "rgba(99,102,241,0.08)"}
                  >{p.label}</button>
                ))}
              </div>
            </div>

            {/* Form grid */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "16px", marginBottom: "20px" }}>
              {/* Job Level */}
              <div>
                <div style={{ fontSize: "10px", color: "#334155", fontFamily: "monospace", letterSpacing: "1px", marginBottom: "8px" }}>JOB LEVEL</div>
                {["Mid senior", "Associate"].map(level => (
                  <button key={level} onClick={() => setJobLevel(level)} style={{
                    display: "block", width: "100%", marginBottom: "6px",
                    background: jobLevel === level ? "rgba(99,102,241,0.2)" : "rgba(255,255,255,0.03)",
                    border: `1px solid ${jobLevel === level ? "rgba(99,102,241,0.5)" : "rgba(255,255,255,0.08)"}`,
                    color: jobLevel === level ? "#A5B4FC" : "#64748B",
                    borderRadius: "8px", padding: "8px 12px", fontSize: "12px",
                    cursor: "pointer", textAlign: "left", fontFamily: "monospace",
                  }}>{level}</button>
                ))}
              </div>

              {/* Job Type */}
              <div>
                <div style={{ fontSize: "10px", color: "#334155", fontFamily: "monospace", letterSpacing: "1px", marginBottom: "8px" }}>JOB TYPE</div>
                {["Onsite", "Remote", "Hybrid"].map(type => (
                  <button key={type} onClick={() => setJobType(type)} style={{
                    display: "block", width: "100%", marginBottom: "6px",
                    background: jobType === type ? "rgba(99,102,241,0.2)" : "rgba(255,255,255,0.03)",
                    border: `1px solid ${jobType === type ? "rgba(99,102,241,0.5)" : "rgba(255,255,255,0.08)"}`,
                    color: jobType === type ? "#A5B4FC" : "#64748B",
                    borderRadius: "8px", padding: "8px 12px", fontSize: "12px",
                    cursor: "pointer", textAlign: "left", fontFamily: "monospace",
                  }}>{type}</button>
                ))}
              </div>

              {/* Company Type */}
              <div>
                <div style={{ fontSize: "10px", color: "#334155", fontFamily: "monospace", letterSpacing: "1px", marginBottom: "8px" }}>COMPANY TYPE</div>
                {["FAANG / Big Tech", "Consulting", "Finance / Banking", "Other"].map(ct => (
                  <button key={ct} onClick={() => setCompanyType(ct)} style={{
                    display: "block", width: "100%", marginBottom: "6px",
                    background: companyType === ct ? "rgba(99,102,241,0.2)" : "rgba(255,255,255,0.03)",
                    border: `1px solid ${companyType === ct ? "rgba(99,102,241,0.5)" : "rgba(255,255,255,0.08)"}`,
                    color: companyType === ct ? "#A5B4FC" : "#64748B",
                    borderRadius: "8px", padding: "7px 12px", fontSize: "11px",
                    cursor: "pointer", textAlign: "left", fontFamily: "monospace",
                  }}>{ct}</button>
                ))}
              </div>
            </div>

            {/* Location */}
            <div style={{ marginBottom: "16px" }}>
              <div style={{ fontSize: "10px", color: "#334155", fontFamily: "monospace", letterSpacing: "1px", marginBottom: "8px" }}>LOCATION (optional)</div>
              <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", marginBottom: "8px" }}>
                {TOP_LOCATIONS.slice(0, 7).map(loc => (
                  <button key={loc} onClick={() => setLocation(loc)} style={{
                    background: location === loc ? "rgba(52,211,153,0.15)" : "rgba(255,255,255,0.03)",
                    border: `1px solid ${location === loc ? "rgba(52,211,153,0.4)" : "rgba(255,255,255,0.07)"}`,
                    color: location === loc ? "#34D399" : "#475569",
                    borderRadius: "6px", padding: "4px 10px", fontSize: "11px",
                    cursor: "pointer", fontFamily: "monospace",
                  }}>{loc}</button>
                ))}
              </div>
              <input value={location} onChange={e => setLocation(e.target.value)}
                placeholder="Or type any location..."
                style={{
                  width: "100%", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: "10px", padding: "10px 14px", color: "#F1F5F9", fontSize: "13px",
                  fontFamily: "monospace",
                }} />
            </div>

            {/* Keywords */}
            <div style={{ marginBottom: "20px", position: "relative" }}>
              <div style={{ fontSize: "10px", color: "#334155", fontFamily: "monospace", letterSpacing: "1px", marginBottom: "8px" }}>
                SKILL / DOMAIN KEYWORDS
              </div>
              {selectedKws.length > 0 && (
                <div style={{ display: "flex", flexWrap: "wrap", gap: "6px", marginBottom: "8px" }}>
                  {selectedKws.map(kw => <Tag key={kw} label={kw} onRemove={() => removeKw(kw)} color="#6366F1" />)}
                </div>
              )}
              <input ref={kwInputRef} value={kwInput} onChange={e => setKwInput(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter" && kwSuggestions.length > 0) addKw(kwSuggestions[0]); if (e.key === "Escape") setShowSug(false); }}
                onBlur={() => setTimeout(() => setShowSug(false), 150)}
                placeholder="Type keyword (e.g. machine learning, sql, docker...)"
                style={{
                  width: "100%", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: "10px", padding: "10px 14px", color: "#F1F5F9", fontSize: "13px",
                  fontFamily: "monospace",
                }} />
              {showSug && kwSuggestions.length > 0 && (
                <div style={{
                  position: "absolute", top: "calc(100% + 6px)", left: 0, right: 0, zIndex: 50,
                  background: "#0F172A", border: "1px solid rgba(99,102,241,0.3)",
                  borderRadius: "10px", overflow: "hidden",
                }}>
                  {kwSuggestions.map((s, i) => (
                    <div key={s} onMouseDown={() => addKw(s)} style={{
                      padding: "10px 14px", cursor: "pointer", fontSize: "12px", fontFamily: "monospace",
                      color: "#94A3B8", borderBottom: i < kwSuggestions.length - 1 ? "1px solid rgba(255,255,255,0.04)" : "none",
                    }}
                      onMouseEnter={e => { e.currentTarget.style.background = "rgba(99,102,241,0.1)"; e.currentTarget.style.color = "#A5B4FC"; }}
                      onMouseLeave={e => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "#94A3B8"; }}
                    >+ {s}</div>
                  ))}
                </div>
              )}
            </div>

            {/* Analyze button */}
            <button onClick={handleAnalyze} disabled={!canAnalyze || loading} style={{
              width: "100%", padding: "15px",
              background: canAnalyze ? "linear-gradient(135deg,#6366F1,#8B5CF6)" : "rgba(255,255,255,0.04)",
              border: "none", borderRadius: "12px",
              color: canAnalyze ? "#fff" : "#334155",
              fontSize: "14px", fontWeight: "700", cursor: canAnalyze ? "pointer" : "not-allowed",
              boxShadow: canAnalyze ? "0 8px 28px rgba(99,102,241,0.25)" : "none",
              transition: "all 0.3s",
            }}>
              {loading ? (
                <span style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "10px" }}>
                  <span style={{ display: "inline-block", width: "14px", height: "14px", border: "2px solid rgba(255,255,255,0.3)", borderTopColor: "#fff", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
                  Running ensemble across 3 models…
                </span>
              ) : "Predict Best-Fit Job Category →"}
            </button>
          </div>

          {/* Results */}
          {results && (
            <div>
              {/* Model agreement */}
              <div style={{
                background: "rgba(99,102,241,0.06)", border: "1px solid rgba(99,102,241,0.2)",
                borderRadius: "12px", padding: "12px 18px", marginBottom: "20px",
                display: "flex", alignItems: "center", gap: "20px", flexWrap: "wrap",
              }}>
                <span style={{ fontSize: "10px", color: "#6366F1", fontFamily: "monospace", letterSpacing: "1px" }}>ENSEMBLE CONSENSUS</span>
                {[["LR (20%)", topRecs[0][0]], ["HGB (40%)", topRecs[0][0]], ["NN (40%)", topRecs[1]?.[0] || topRecs[0][0]]].map(([model, pred]) => (
                  <span key={model} style={{ fontSize: "11px", color: "#64748B", fontFamily: "monospace" }}>
                    <span style={{ color: "#334155" }}>{model}: </span>
                    <span style={{ color: "#A5B4FC" }}>{pred}</span>
                  </span>
                ))}
              </div>

              {/* Top 3 cards */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(300px,1fr))", gap: "14px", marginBottom: "0" }}>
                {topRecs.map(([role, prob], i) => (
                  <JobCard key={role} role={role} confidence={prob} rank={i + 1} allProbs={results} delay={i * 130} />
                ))}
              </div>

              {/* Full distribution chart */}
              <ScoreChart allProbs={results} />

              {/* Architecture explainer */}
              <div style={{
                marginTop: "20px", background: "rgba(255,255,255,0.02)",
                border: "1px solid rgba(255,255,255,0.06)", borderRadius: "12px", padding: "18px",
              }}>
                <div style={{ fontSize: "10px", color: "#334155", fontFamily: "monospace", letterSpacing: "1px", marginBottom: "10px" }}>ARCHITECTURE NOTE</div>
                <p style={{ fontSize: "12px", color: "#475569", lineHeight: 1.7, margin: 0 }}>
                  Trained on <strong style={{ color: "#64748B" }}>9,538 real LinkedIn job postings</strong> with 70 engineered features derived from job metadata (level, type, location, title keywords, company type). The ensemble uses <span style={{ color: "#C084FC" }}>Logistic Regression (20%)</span> + <span style={{ color: "#34D399" }}>HistGradientBoosting (40%)</span> + <span style={{ color: "#60A5FA" }}>Neural Network (40%)</span>. Class imbalance (2,475 Data Analysts vs 29 AI Researchers) is handled via balanced class weights in all three models.
                </p>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
