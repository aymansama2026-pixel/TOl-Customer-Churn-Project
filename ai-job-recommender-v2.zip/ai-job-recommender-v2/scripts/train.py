"""
Master Training Pipeline — Real LinkedIn Dataset
=================================================
Run: python scripts/train.py [--skip-dl]
"""

import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--skip-dl', action='store_true', help='Skip neural network')
    parser.add_argument('--models-dir', default='models')
    args = parser.parse_args()

    os.makedirs(args.models_dir, exist_ok=True)
    os.makedirs(f'{args.models_dir}/artifacts', exist_ok=True)

    t0 = time.time()
    print('\n' + '═'*60)
    print('  🤖  AI JOB RECOMMENDER v2 — REAL DATASET TRAINING')
    print('  📊  Source: job_postings.csv (LinkedIn, 12,217 rows)')
    print('═'*60)

    # ── Step 1: Process dataset ───────────────────────────────────────────────
    print('\n[1/5] 🔧 Processing real dataset...')
    import pandas as pd
    from data.process_dataset import build_dataset
    df, feature_names = build_dataset(
        raw_path='data/raw/job_postings.csv',
        save_dir='data/processed',
    )

    # ── Step 2: Preprocess ────────────────────────────────────────────────────
    print('\n[2/5] ⚙️  Splitting & scaling...')
    from src.utils.preprocessing import preprocess
    data = preprocess(df, save_artifacts=True, artifacts_dir=f'{args.models_dir}/artifacts')

    # ── Step 3: ML Models ─────────────────────────────────────────────────────
    print('\n[3/5] 🌲 Training ML models (LR + XGBoost)...')
    from src.ml.train_ml import run_ml_training
    ml_results = run_ml_training(data, models_dir=args.models_dir)

    # ── Step 4: Neural Network ────────────────────────────────────────────────
    dl_results = None
    if not args.skip_dl:
        print('\n[4/5] 🧠 Training Neural Network...')
        from src.dl.train_dl import run_dl_training
        dl_results = run_dl_training(data, models_dir=args.models_dir)
    else:
        print('\n[4/5] ⏭️  Skipping neural network')

    # ── Step 5: NLP title matcher ─────────────────────────────────────────────
    print('\n[5/5] 📝 Building TF-IDF title matcher...')
    from src.nlp.title_matcher import build_title_matcher
    build_title_matcher(
        csv_path='data/raw/job_postings.csv',
        save_path=f'{args.models_dir}/artifacts/title_matcher.pkl',
    )

    # ── Summary ───────────────────────────────────────────────────────────────
    elapsed = round(time.time() - t0, 1)
    print('\n' + '═'*60)
    print('  📈  RESULTS SUMMARY')
    print('═'*60)
    lr_acc  = ml_results['logistic_regression']['eval']['accuracy']
    lr_f1   = ml_results['logistic_regression']['eval']['macro_f1']
    xgb_acc = ml_results['xgboost']['eval']['accuracy']
    xgb_f1  = ml_results['xgboost']['eval']['macro_f1']
    print(f'  Logistic Regression : Acc={lr_acc*100:.1f}%  Macro-F1={lr_f1:.3f}')
    print(f'  XGBoost             : Acc={xgb_acc*100:.1f}%  Macro-F1={xgb_f1:.3f}')
    if dl_results:
        nn_acc = dl_results['eval']['accuracy']
        nn_f1  = dl_results['eval']['macro_f1']
        print(f'  Neural Network      : Acc={nn_acc*100:.1f}%  Macro-F1={nn_f1:.3f}')
    print(f'\n  Dataset: {len(df):,} samples  |  {data["n_features"]} features  |  {data["n_classes"]} classes')
    print(f'  ⏱️  Total: {elapsed}s')
    print('═'*60)
    print('\n✅ Done! Start API:')
    print('   uvicorn src.api.main:app --reload --port 8000\n')

    summary = {
        'lr_accuracy': lr_acc, 'lr_macro_f1': lr_f1,
        'xgb_accuracy': xgb_acc, 'xgb_macro_f1': xgb_f1,
        'nn_accuracy': dl_results['eval']['accuracy'] if dl_results else None,
        'nn_macro_f1': dl_results['eval']['macro_f1'] if dl_results else None,
        'n_samples': len(df), 'n_features': data['n_features'], 'n_classes': data['n_classes'],
    }
    with open(f'{args.models_dir}/artifacts/training_summary.json', 'w') as f:
        json.dump(summary, f, indent=2)


if __name__ == '__main__':
    main()
