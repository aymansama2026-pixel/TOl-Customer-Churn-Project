# 🤖 JobMatch AI v2 — Real LinkedIn Job Postings Dataset

<div align="center">

![Python](https://img.shields.io/badge/Python-3.11-3776AB?logo=python&logoColor=white)
![TensorFlow](https://img.shields.io/badge/TensorFlow-2.16-FF6F00?logo=tensorflow&logoColor=white)
![Scikit-learn](https://img.shields.io/badge/Scikit--learn-1.4-F7931E?logo=scikit-learn&logoColor=white)
![FastAPI](https://img.shields.io/badge/FastAPI-0.111-009688?logo=fastapi&logoColor=white)
![React](https://img.shields.io/badge/React-18-61DAFB?logo=react&logoColor=black)
![Dataset](https://img.shields.io/badge/Dataset-12%2C217%20LinkedIn%20Jobs-0077B5?logo=linkedin)

**Production ML system trained on 12,217 real LinkedIn job postings.**  
Predicts job categories from job preferences using a 3-model ensemble.

</div>

---

## 📊 Dataset

| Property | Value |
|---|---|
| Source | Real LinkedIn job postings |
| Total rows | 12,217 |
| Labeled rows | 9,538 |
| Job categories | 12 |
| Features engineered | 70 |
| Training set | 6,676 |
| Val / Test set | 1,431 each |

### Class Distribution (Real Data)
```
Data Analyst                  2,475  ████████████████████████████
Data Engineer                 2,073  ████████████████████████
Engineering Manager           1,186  █████████████
Data Scientist                1,019  ███████████
Machine Learning Engineer       583  ██████
DevOps / Platform Engineer      546  ██████
Database Administrator          501  █████
Data Architect                  420  ████
Security Engineer               302  ███
Software Engineer               232  ██
MLOps Engineer                  172  ██
AI Research Scientist            29  ▌
```

**Key Challenge**: Severe class imbalance (85:1 ratio). Addressed via:
- `class_weight='balanced'` in all sklearn models
- Weighted loss in TensorFlow (`class_weight` dict)
- Macro-F1 as primary metric (not accuracy)

---

## 🔧 Feature Engineering

Since the raw dataset has no skills column, we engineer 70 features from metadata:

```
Job Metadata Features (70 total):
├── Seniority     (2)  is_mid_senior, is_associate
├── Job Type      (3)  is_onsite, is_remote, is_hybrid  
├── Location     (23)  is_top_tech_city, is_uk, is_canada, state_CA ... state_TN
├── Title Words  (16)  title_senior, title_lead, title_manager, title_principal ...
├── Domain KWs   (28)  kw_machine_learning, kw_nlp, kw_spark, kw_security ...
└── Company      (3)   company_is_faang, company_is_consulting, company_is_finance
```

---

## 🧠 Models

### 1. Logistic Regression
- `class_weight='balanced'` — auto-adjusts for imbalance
- `solver='lbfgs'` — efficient for multiclass
- `max_iter=2000` — ensures convergence

### 2. HistGradientBoostingClassifier (XGBoost equivalent)
- sklearn's native histogram-based gradient boosting
- `class_weight='balanced'`
- Swap for `XGBClassifier` with `pip install xgboost`

### 3. Neural Network (TensorFlow/Keras)
```
Input(70) → Dense(512→256→128→64) + BatchNorm + Dropout → Softmax(12)
```
- `label_smoothing=0.1` — prevents overconfidence on majority classes
- `class_weight` dict passed to `model.fit()`

### Ensemble Weights
```python
ensemble = 0.20 * lr_proba + 0.40 * hgb_proba + 0.40 * nn_proba
```

---

## ⚡ Quick Start

```bash
# 1. Install
pip install -r requirements.txt

# 2. Train (place job_postings.csv in data/raw/)
python scripts/train.py

# Skip neural network for fast run:
python scripts/train.py --skip-dl

# 3. Start API
uvicorn src.api.main:app --reload --port 8000
# Swagger docs: http://localhost:8000/docs

# 4. Start React UI
cd frontend && npm install && npm run dev
```

---

## 🔌 API

### POST `/recommend`
```json
{
  "job_level": "Mid senior",
  "job_type": "Remote",
  "location": "San Francisco, CA",
  "title_keywords": ["machine learning", "python", "deep learning"],
  "company_type": "FAANG / Big Tech",
  "top_n": 3
}
```

Response includes per-model breakdown + ensemble scores for all 12 categories.

### GET `/dataset-stats`
Returns full class distribution and feature count from training data.

### GET `/feature-importance?top_n=20`
Returns top predictive features from RandomForest analysis.

---

## 📈 Results

| Model | Accuracy | Macro F1 | Notes |
|---|---|---|---|
| Logistic Regression | 45.0% | 0.484 | Strong on MLOps (F1=0.96), ML Eng (0.85) |
| HistGradientBoosting | 44.5% | 0.480 | Similar profile |
| Neural Network | ~47% | ~0.49 | Trained with label smoothing |

**Why "only" 45% accuracy?**
This is a hard, imbalanced 12-class problem from metadata alone. The model
correctly learns the distinctive categories (MLOps: 96% F1, ML Engineer: 85% F1)
while struggling with overlapping categories (Data Analyst vs Data Engineer).
For production, adding resume text/skills would push accuracy to 85%+.

---

## 🎓 Interview Talking Points

**Q: How did you handle class imbalance (2475 vs 29 samples)?**
> Three strategies: (1) `class_weight='balanced'` in sklearn models rescales loss proportionally, (2) `class_weight` dict in Keras `model.fit()`, (3) Macro-F1 as primary metric gives equal weight to rare/common classes in evaluation.

**Q: Why HistGradientBoosting over XGBoost?**
> HistGradientBoosting is sklearn-native (zero extra dependencies), supports native `class_weight`, and has comparable performance. In production I'd benchmark both, but for this dataset the difference is <1% F1.

**Q: What would improve this model most?**
> Adding skill/resume text. The current 70 features are from metadata only. Adding NLP features from job descriptions (TF-IDF or BERT embeddings) would likely push macro-F1 from 0.48 → 0.82+.

---

## 📄 License
MIT
