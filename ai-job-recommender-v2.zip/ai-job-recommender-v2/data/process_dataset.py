"""
Real Dataset Processor — job_postings.csv
==========================================
Transforms the raw LinkedIn job postings CSV into a feature matrix
suitable for ML classification.

Source data: 12,217 real LinkedIn job postings
Features engineered:
  - job_level (Associate / Mid-Senior)       → binary
  - job_type (Onsite / Remote / Hybrid)      → one-hot
  - city_tier (top tech hub / uk / canada)   → one-hot
  - state (CA, TX, NY ...)                   → top-N encoded
  - title keywords (senior, lead, staff...)  → binary flags
  - company size proxy from title patterns   → binary

Target: job_category (12 classes derived from job_title NLP parsing)

Design Decision:
We derive features purely from the metadata columns since we have no
skills/resume text in this dataset. The classifier learns which
combinations of seniority + location + job-type + title keywords
map to which role category — a realistic "job categorizer" use case.

For the recommendation UI, we reverse this: given a user's desired
level + location + keywords, we predict the best-matching job category.
"""

import json
import os
import re

import numpy as np
import pandas as pd


# ── Job category taxonomy ─────────────────────────────────────────────────────

def categorize_title(title: str) -> str | None:
    t = title.lower()
    if any(x in t for x in ['ml engineer','machine learning engineer','mls engineer',
                              'ml accelerator','ml platform','machine learning scientist']):
        return 'Machine Learning Engineer'
    if any(x in t for x in ['mlops','ml ops']):
        return 'MLOps Engineer'
    if any(x in t for x in ['data scientist','data science','quantitative analyst',
                              'quant analyst','applied scientist']):
        return 'Data Scientist'
    if any(x in t for x in ['data engineer','etl','data warehouse','data pipeline',
                              'analytics engineer','data integration','data modeler','master data']):
        return 'Data Engineer'
    if any(x in t for x in ['data analyst','business analyst','bi analyst',
                              'business intelligence','reporting analyst','operations analyst',
                              'data analytics','data management analyst','data steward',
                              'data management specialist','data entry']):
        return 'Data Analyst'
    if any(x in t for x in ['data architect','database architect','solutions architect',
                              'enterprise architect']):
        return 'Data Architect'
    if any(x in t for x in ['database admin','dba','database developer','database engineer']):
        return 'Database Administrator'
    if any(x in t for x in ['software engineer','software developer','backend',
                              'full stack','fullstack','frontend','front-end','distinguished engineer']):
        return 'Software Engineer'
    if any(x in t for x in ['ai research','research scientist','nlp researcher',
                              'computer vision researcher','applied research']):
        return 'AI Research Scientist'
    if any(x in t for x in ['data loss prevention','dlp','security','cybersecurity',
                              'information security','infosec','cyber']):
        return 'Security Engineer'
    if any(x in t for x in ['manager','director','head of','vp of','vice president']):
        return 'Engineering Manager'
    if any(x in t for x in ['devops','platform engineer','infrastructure','cloud engineer',
                              'sre','site reliability','network engineer',
                              'datacenter','data center','data cabling']):
        return 'DevOps / Platform Engineer'
    return None


# ── Feature engineering ───────────────────────────────────────────────────────

TOP_STATES = ['CA', 'TX', 'NY', 'VA', 'IL', 'NJ', 'PA', 'FL', 'MA', 'WA',
              'GA', 'OH', 'NC', 'CO', 'MN', 'AZ', 'MI', 'MD', 'OR', 'TN']

TOP_TECH_CITIES = ['new york','san francisco','seattle','austin','boston',
                   'chicago','washington','los angeles','dallas','atlanta',
                   'denver','portland','san jose','san diego','raleigh']


def extract_features(df: pd.DataFrame) -> pd.DataFrame:
    """Engineer all features from raw job posting columns."""
    feat = pd.DataFrame()

    # ── 1. Seniority level ────────────────────────────────────────────────────
    feat['is_mid_senior'] = (df['job_level'] == 'Mid senior').astype(int)
    feat['is_associate']  = (df['job_level'] == 'Associate').astype(int)

    # ── 2. Job type ───────────────────────────────────────────────────────────
    feat['is_remote'] = (df['job_type'] == 'Remote').astype(int)
    feat['is_hybrid'] = (df['job_type'] == 'Hybrid').astype(int)
    feat['is_onsite'] = (df['job_type'] == 'Onsite').astype(int)

    # ── 3. Location features ──────────────────────────────────────────────────
    loc = df['job_location'].fillna('')

    feat['is_top_tech_city'] = loc.str.lower().apply(
        lambda l: int(any(c in l for c in TOP_TECH_CITIES))
    )
    feat['is_uk']     = loc.str.contains('United Kingdom|London', na=False).astype(int)
    feat['is_canada'] = loc.str.contains('Canada|Toronto|Vancouver|Calgary|Montreal', na=False).astype(int)

    # State dummies (top 20 states as binary features)
    def get_state(l):
        if pd.isna(l): return ''
        parts = str(l).split(',')
        if len(parts) >= 2:
            s = parts[1].strip()
            return s if len(s) <= 3 else ''
        return ''

    states = df['job_location'].apply(get_state)
    for st in TOP_STATES:
        feat[f'state_{st}'] = (states == st).astype(int)

    # ── 4. Title keyword features ─────────────────────────────────────────────
    title = df['job_title'].str.lower()

    seniority_words = ['senior','sr.','sr ','lead','principal','staff',
                       'head of','director','manager','associate','junior','jr.']
    for word in seniority_words:
        col = 'title_' + re.sub(r'[^a-z]', '', word)
        feat[col] = title.str.contains(word, na=False).astype(int)

    # Domain keywords in title
    domain_keywords = [
        'machine learning','deep learning','nlp','computer vision',
        'data science','data engineering','analytics','mlops','cloud',
        'python','sql','spark','aws','azure','gcp','kubernetes','docker',
        'tableau','power bi','looker','dbt','airflow','kafka','snowflake',
        'security','compliance','architecture','research',
    ]
    for kw in domain_keywords:
        col = 'kw_' + kw.replace(' ', '_')
        feat[col] = title.str.contains(kw, na=False).astype(int)

    # ── 5. Company name signals ───────────────────────────────────────────────
    company = df['company'].str.lower().fillna('')
    feat['company_is_faang'] = company.str.contains(
        'google|amazon|meta|microsoft|apple|netflix|nvidia|openai|anthropic|databricks',
        na=False
    ).astype(int)
    feat['company_is_consulting'] = company.str.contains(
        'deloitte|accenture|pwc|kpmg|mckinsey|bain|bcg|booz|capgemini|cognizant|infosys|wipro|tcs',
        na=False
    ).astype(int)
    feat['company_is_finance'] = company.str.contains(
        'bank|capital|jpmorgan|goldman|morgan stanley|wells fargo|citi|blackrock|fidelity|vanguard',
        na=False
    ).astype(int)

    return feat


def build_dataset(
    raw_path: str = 'data/raw/job_postings.csv',
    save_dir: str = 'data/processed',
    min_samples_per_class: int = 29,
) -> tuple[pd.DataFrame, list[str]]:
    """
    Load raw CSV, engineer features, filter low-count classes, save processed data.
    Returns (feature_df_with_label, feature_column_names)
    """
    print(f"📂 Loading: {raw_path}")
    df = pd.read_csv(raw_path)
    print(f"   Raw shape: {df.shape}")

    # Label engineering
    df['job_category'] = df['job_title'].apply(categorize_title)
    df = df[df['job_category'].notna()].reset_index(drop=True)
    print(f"   After category filter: {len(df)} rows")

    # Drop tiny classes
    class_counts = df['job_category'].value_counts()
    valid_classes = class_counts[class_counts >= min_samples_per_class].index.tolist()
    df = df[df['job_category'].isin(valid_classes)].reset_index(drop=True)
    print(f"   After min-class filter: {len(df)} rows, {len(valid_classes)} classes")

    # Feature engineering
    features = extract_features(df)
    feature_names = features.columns.tolist()

    # Combine features + label
    out = features.copy()
    out['job_category'] = df['job_category'].values

    # Save
    os.makedirs(save_dir, exist_ok=True)
    out.to_csv(f'{save_dir}/features.csv', index=False)

    # Save metadata
    meta = {
        'feature_names': feature_names,
        'job_categories': valid_classes,
        'n_samples': len(out),
        'n_features': len(feature_names),
        'class_distribution': df['job_category'].value_counts().to_dict(),
    }
    with open(f'{save_dir}/metadata.json', 'w') as f:
        json.dump(meta, f, indent=2)

    print(f"\n✅ Processed dataset saved to {save_dir}/")
    print(f"   Features: {len(feature_names)}")
    print(f"   Classes:  {len(valid_classes)}")
    print(f"\n   Class distribution:")
    for cls, cnt in sorted(meta['class_distribution'].items(), key=lambda x: -x[1]):
        print(f"   {cls:35s} {cnt:5d}")

    return out, feature_names


if __name__ == '__main__':
    build_dataset()
