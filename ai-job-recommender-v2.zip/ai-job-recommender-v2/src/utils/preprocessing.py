"""
Data Preprocessing Pipeline
============================
Handles train/val/test splitting and feature scaling for the
real job_postings dataset.

Key challenge with this dataset:
- Highly imbalanced classes (Data Analyst: 2475 vs AI Research: 29)
- We use stratified splits to preserve class ratios in all splits
- class_weight='balanced' in sklearn models handles the imbalance
- For XGBoost: scale_pos_weight per class via sample_weight
- For Neural Network: class_weight dict passed to model.fit()
"""

import json
import os
import pickle

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.utils.class_weight import compute_class_weight


def load_processed_data(path: str = 'data/processed/features.csv') -> pd.DataFrame:
    return pd.read_csv(path)


def preprocess(
    df: pd.DataFrame,
    test_size: float = 0.15,
    val_size: float = 0.15,
    save_artifacts: bool = True,
    artifacts_dir: str = 'models/artifacts',
) -> dict:
    feature_cols = [c for c in df.columns if c != 'job_category']
    X = df[feature_cols].values.astype(np.float32)
    y_raw = df['job_category'].values

    # ── Label encoding ─────────────────────────────────────────────────────────
    encoder = LabelEncoder()
    y = encoder.fit_transform(y_raw)

    # ── Class weights (for imbalanced dataset) ─────────────────────────────────
    classes = np.unique(y)
    weights = compute_class_weight('balanced', classes=classes, y=y)
    class_weight_dict = dict(zip(classes, weights))

    # ── Stratified splits ──────────────────────────────────────────────────────
    X_train, X_temp, y_train, y_temp = train_test_split(
        X, y, test_size=(test_size + val_size), random_state=42, stratify=y
    )
    rel_val = val_size / (test_size + val_size)
    X_val, X_test, y_val, y_test = train_test_split(
        X_temp, y_temp, test_size=(1 - rel_val), random_state=42, stratify=y_temp
    )

    # ── Feature scaling (fit on train only) ───────────────────────────────────
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_val_scaled   = scaler.transform(X_val)
    X_test_scaled  = scaler.transform(X_test)

    # ── Save ───────────────────────────────────────────────────────────────────
    if save_artifacts:
        os.makedirs(artifacts_dir, exist_ok=True)
        with open(f'{artifacts_dir}/scaler.pkl', 'wb') as f:
            pickle.dump(scaler, f)
        with open(f'{artifacts_dir}/label_encoder.pkl', 'wb') as f:
            pickle.dump(encoder, f)
        with open(f'{artifacts_dir}/feature_names.json', 'w') as f:
            json.dump(feature_cols, f)
        with open(f'{artifacts_dir}/class_weights.json', 'w') as f:
            json.dump({str(k): float(v) for k, v in class_weight_dict.items()}, f)
        print(f'✅ Artifacts saved → {artifacts_dir}/')

    print(f'Train: {X_train.shape}  Val: {X_val.shape}  Test: {X_test.shape}')
    print(f'Classes ({len(encoder.classes_)}): {list(encoder.classes_)}')

    return {
        'X_train': X_train, 'X_val': X_val, 'X_test': X_test,
        'X_train_scaled': X_train_scaled,
        'X_val_scaled':   X_val_scaled,
        'X_test_scaled':  X_test_scaled,
        'y_train': y_train, 'y_val': y_val, 'y_test': y_test,
        'feature_names': feature_cols,
        'class_names': list(encoder.classes_),
        'class_weight_dict': class_weight_dict,
        'scaler': scaler,
        'encoder': encoder,
        'n_features': len(feature_cols),
        'n_classes': len(encoder.classes_),
    }
