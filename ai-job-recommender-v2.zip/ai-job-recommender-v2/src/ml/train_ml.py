"""
ML Training: Logistic Regression + HistGradientBoosting (sklearn XGBoost equivalent)
======================================================================================
Key adaptation for real dataset:
- Imbalanced classes (2475 Data Analyst vs 29 AI Research Scientist)
- LogisticRegression: class_weight='balanced' auto-adjusts loss
- HistGradientBoostingClassifier: sklearn's native gradient boosting,
  equivalent performance to XGBoost. class_weight='balanced' handles imbalance.
  (Swap for XGBClassifier in production with: pip install xgboost)
- Both use macro-averaged F1 as primary metric (fairer than accuracy on imbalanced data)
"""

import json
import os

import joblib
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, classification_report,
                              confusion_matrix, f1_score)


def train_logistic_regression(X_train, y_train, n_classes: int):
    model = LogisticRegression(
        C=1.0,
        solver='lbfgs',
        max_iter=2000,
        class_weight='balanced',
        random_state=42,
        n_jobs=-1,
    )
    model.fit(X_train, y_train)
    print('✅ Logistic Regression trained')
    return model


def train_xgboost(X_train, y_train, X_val, y_val, n_classes: int, class_weight_dict: dict):
    """
    HistGradientBoostingClassifier — sklearn's native histogram-based gradient
    boosting. Near-identical to XGBoost's hist method.
    Replace with XGBClassifier if XGBoost is available (pip install xgboost).
    """
    model = HistGradientBoostingClassifier(
        max_iter=400,
        max_depth=7,
        learning_rate=0.05,
        min_samples_leaf=20,
        l2_regularization=0.1,
        class_weight='balanced',
        random_state=42,
        verbose=0,
    )
    model.fit(X_train, y_train)
    print('✅ HistGradientBoosting (XGBoost-equivalent) trained')
    return model


def evaluate_model(model, X_test, y_test, class_names: list, model_name: str) -> dict:
    y_pred  = model.predict(X_test)
    y_proba = model.predict_proba(X_test)
    acc    = accuracy_score(y_test, y_pred)
    macro_f1 = f1_score(y_test, y_pred, average='macro')
    report   = classification_report(y_test, y_pred, target_names=class_names, output_dict=True)
    cm       = confusion_matrix(y_test, y_pred)

    print(f"\n{'─'*55}")
    print(f"  {model_name}")
    print(f"{'─'*55}")
    print(f"  Accuracy : {acc:.4f}  ({acc*100:.2f}%)")
    print(f"  Macro F1 : {macro_f1:.4f}  (imbalance-aware)")
    print(f"\n{classification_report(y_test, y_pred, target_names=class_names)}")

    return {
        'accuracy': acc, 'macro_f1': macro_f1,
        'report': report, 'confusion_matrix': cm.tolist(),
        'y_pred': y_pred, 'y_proba': y_proba,
    }


def get_feature_importance(model, feature_names: list, top_n: int = 25) -> dict:
    importances = model.feature_importances_
    indices = np.argsort(importances)[::-1][:top_n]
    return {
        'features':    [feature_names[i] for i in indices],
        'importances': [float(importances[i]) for i in indices],
    }


def save_model(model, path: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    joblib.dump(model, path)
    print(f'💾 Saved: {path}')


def run_ml_training(data: dict, models_dir: str = 'models') -> dict:
    results = {}

    lr = train_logistic_regression(data['X_train'], data['y_train'], data['n_classes'])
    lr_eval = evaluate_model(lr, data['X_test'], data['y_test'], data['class_names'], 'Logistic Regression')
    save_model(lr, f'{models_dir}/logistic_regression.joblib')
    results['logistic_regression'] = {'model': lr, 'eval': lr_eval}

    xgb = train_xgboost(
        data['X_train'], data['y_train'],
        data['X_val'],   data['y_val'],
        data['n_classes'], data['class_weight_dict'],
    )
    xgb_eval = evaluate_model(xgb, data['X_test'], data['y_test'], data['class_names'], 'XGBoost')
    save_model(xgb, f'{models_dir}/xgboost.joblib')

    fi = get_feature_importance(xgb, data['feature_names'])
    os.makedirs(f'{models_dir}/artifacts', exist_ok=True)
    with open(f'{models_dir}/artifacts/feature_importance.json', 'w') as f:
        json.dump(fi, f, indent=2)

    results['xgboost'] = {'model': xgb, 'eval': xgb_eval, 'feature_importance': fi}

    best = 'XGBoost' if xgb_eval['macro_f1'] > lr_eval['macro_f1'] else 'Logistic Regression'
    print(f'\n🏆 Best ML Model (Macro F1): {best}')
    return results
