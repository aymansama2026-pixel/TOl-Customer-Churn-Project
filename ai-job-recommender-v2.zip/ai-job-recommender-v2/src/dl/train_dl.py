"""
Deep Learning: TensorFlow/Keras Neural Network
================================================
Adaptations for the real job_postings dataset:
- class_weight dict passed to model.fit() for imbalance handling
- Focal-loss-like effect via class weighting (rare classes get higher loss weight)
- Label smoothing (0.1) in CategoricalCrossentropy: prevents overconfident predictions
  on the majority classes — important when AI Research Scientist has only 29 samples
"""

import json
import os

import numpy as np
import tensorflow as tf
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score
from tensorflow.keras import callbacks, layers, models, optimizers
from tensorflow.keras.utils import to_categorical


def build_model(n_features: int, n_classes: int, dropout_rate: float = 0.35) -> tf.keras.Model:
    """
    MLP with BatchNorm + Dropout.
    Slightly deeper than v1 to handle 70 features → 12 classes.
    Label smoothing in loss function handles overconfidence on majority classes.
    """
    model = models.Sequential([
        layers.Input(shape=(n_features,), name='job_features'),

        layers.Dense(512, name='dense_1'),
        layers.BatchNormalization(), layers.Activation('relu'),
        layers.Dropout(dropout_rate),

        layers.Dense(256, name='dense_2'),
        layers.BatchNormalization(), layers.Activation('relu'),
        layers.Dropout(dropout_rate),

        layers.Dense(128, name='dense_3'),
        layers.BatchNormalization(), layers.Activation('relu'),
        layers.Dropout(dropout_rate * 0.7),

        layers.Dense(64, name='dense_4'),
        layers.BatchNormalization(), layers.Activation('relu'),
        layers.Dropout(0.1),

        layers.Dense(n_classes, activation='softmax', name='output'),
    ], name='JobClassifier_v2')
    return model


def train_neural_network(
    X_train_scaled, y_train,
    X_val_scaled,   y_val,
    n_features: int, n_classes: int,
    class_weight_dict: dict,
    models_dir: str = 'models',
    epochs: int = 120,
    batch_size: int = 128,
) -> tuple:
    os.makedirs(models_dir, exist_ok=True)

    y_train_oh = to_categorical(y_train, n_classes)
    y_val_oh   = to_categorical(y_val,   n_classes)

    model = build_model(n_features, n_classes)
    model.compile(
        optimizer=optimizers.Adam(learning_rate=1e-3),
        # Label smoothing=0.1: prevents >95% confidence on imbalanced majority
        loss=tf.keras.losses.CategoricalCrossentropy(label_smoothing=0.1),
        metrics=['accuracy'],
    )
    model.summary()

    cbs = [
        callbacks.EarlyStopping(monitor='val_accuracy', patience=18,
                                restore_best_weights=True, verbose=1),
        callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.5,
                                    patience=8, min_lr=1e-6, verbose=1),
        callbacks.ModelCheckpoint(f'{models_dir}/nn_checkpoint.keras',
                                  monitor='val_accuracy', save_best_only=True, verbose=0),
    ]

    history = model.fit(
        X_train_scaled, y_train_oh,
        validation_data=(X_val_scaled, y_val_oh),
        epochs=epochs,
        batch_size=batch_size,
        class_weight=class_weight_dict,   # ← handles imbalance
        callbacks=cbs,
        verbose=1,
    )
    print('✅ Neural Network trained')
    return model, history.history


def evaluate_neural_network(model, X_test_scaled, y_test, class_names) -> dict:
    y_proba = model.predict(X_test_scaled, verbose=0)
    y_pred  = np.argmax(y_proba, axis=1)
    acc      = accuracy_score(y_test, y_pred)
    macro_f1 = f1_score(y_test, y_pred, average='macro')
    report   = classification_report(y_test, y_pred, target_names=class_names, output_dict=True)
    cm       = confusion_matrix(y_test, y_pred)

    print(f"\n{'─'*55}")
    print(f"  Neural Network")
    print(f"{'─'*55}")
    print(f"  Accuracy : {acc:.4f}  ({acc*100:.2f}%)")
    print(f"  Macro F1 : {macro_f1:.4f}")
    print(f"\n{classification_report(y_test, y_pred, target_names=class_names)}")
    return {
        'accuracy': acc, 'macro_f1': macro_f1,
        'report': report, 'confusion_matrix': cm.tolist(),
        'y_pred': y_pred, 'y_proba': y_proba,
    }


def run_dl_training(data: dict, models_dir: str = 'models') -> dict:
    model, history = train_neural_network(
        data['X_train_scaled'], data['y_train'],
        data['X_val_scaled'],   data['y_val'],
        n_features=data['n_features'],
        n_classes=data['n_classes'],
        class_weight_dict=data['class_weight_dict'],
        models_dir=models_dir,
    )
    dl_eval = evaluate_neural_network(
        model, data['X_test_scaled'], data['y_test'], data['class_names']
    )
    model.save(f'{models_dir}/neural_network.keras')
    print(f'💾 Saved: {models_dir}/neural_network.keras')

    os.makedirs(f'{models_dir}/artifacts', exist_ok=True)
    with open(f'{models_dir}/artifacts/nn_history.json', 'w') as f:
        json.dump({k: [float(v) for v in vals] for k, vals in history.items()}, f)

    return {'model': model, 'history': history, 'eval': dl_eval}
