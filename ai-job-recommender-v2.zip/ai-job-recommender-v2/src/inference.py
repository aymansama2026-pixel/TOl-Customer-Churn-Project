"""
Inference Engine
=================
Accepts structured job search criteria (level, location, job type,
title keywords) and returns top-3 job category predictions.

This is the production inference path using the trained ensemble.
"""

import json
import os
import pickle
from typing import Optional

import joblib
import numpy as np
import tensorflow as tf

# ── Feature engineering (mirrors process_dataset.py) ─────────────────────────
TOP_STATES = ['CA', 'TX', 'NY', 'VA', 'IL', 'NJ', 'PA', 'FL', 'MA', 'WA',
              'GA', 'OH', 'NC', 'CO', 'MN', 'AZ', 'MI', 'MD', 'OR', 'TN']
TOP_TECH_CITIES = ['new york','san francisco','seattle','austin','boston',
                   'chicago','washington','los angeles','dallas','atlanta',
                   'denver','portland','san jose','san diego','raleigh']


class ModelRegistry:
    def __init__(self, models_dir: str = 'models'):
        self.models_dir = models_dir
        self._lr = self._xgb = self._nn = None
        self._scaler = self._encoder = self._features = None

    def _load_artifacts(self):
        a = f'{self.models_dir}/artifacts'
        with open(f'{a}/feature_names.json') as f:
            self._features = json.load(f)
        with open(f'{a}/scaler.pkl', 'rb') as f:
            self._scaler = pickle.load(f)
        with open(f'{a}/label_encoder.pkl', 'rb') as f:
            self._encoder = pickle.load(f)

    @property
    def lr(self):
        if not self._lr: self._lr = joblib.load(f'{self.models_dir}/logistic_regression.joblib')
        return self._lr

    @property
    def xgb(self):
        if not self._xgb: self._xgb = joblib.load(f'{self.models_dir}/xgboost.joblib')
        return self._xgb

    @property
    def nn(self):
        if not self._nn: self._nn = tf.keras.models.load_model(f'{self.models_dir}/neural_network.keras')
        return self._nn

    @property
    def scaler(self):
        if not self._scaler: self._load_artifacts()
        return self._scaler

    @property
    def encoder(self):
        if not self._encoder: self._load_artifacts()
        return self._encoder

    @property
    def feature_names(self):
        if not self._features: self._load_artifacts()
        return self._features


_registry: Optional[ModelRegistry] = None


def get_registry(models_dir: str = 'models') -> ModelRegistry:
    global _registry
    if _registry is None:
        _registry = ModelRegistry(models_dir)
    return _registry


def encode_input(
    job_level: str,
    job_type: str,
    location: str,
    title_keywords: list[str],
    company_type: str,
    feature_names: list[str],
) -> np.ndarray:
    """
    Encode user inputs into the same feature vector used during training.
    All feature names are read from the saved feature_names.json.
    """
    feat = {name: 0.0 for name in feature_names}

    # Level
    if job_level == 'Mid senior': feat['is_mid_senior'] = 1.0
    if job_level == 'Associate':  feat['is_associate']  = 1.0

    # Job type
    if job_type == 'Remote': feat['is_remote'] = 1.0
    elif job_type == 'Hybrid': feat['is_hybrid'] = 1.0
    else: feat['is_onsite'] = 1.0

    # Location
    loc_lower = location.lower()
    if any(c in loc_lower for c in TOP_TECH_CITIES):
        feat['is_top_tech_city'] = 1.0
    if 'uk' in loc_lower or 'united kingdom' in loc_lower or 'london' in loc_lower:
        feat['is_uk'] = 1.0
    if 'canada' in loc_lower:
        feat['is_canada'] = 1.0
    # State extraction
    for st in TOP_STATES:
        if f', {st.lower()}' in loc_lower or f' {st.lower()}' in loc_lower:
            if f'state_{st}' in feat:
                feat[f'state_{st}'] = 1.0

    # Title keywords
    kw_map = {
        'machine learning': 'kw_machine_learning',
        'deep learning': 'kw_deep_learning',
        'nlp': 'kw_nlp',
        'computer vision': 'kw_computer_vision',
        'data science': 'kw_data_science',
        'data engineering': 'kw_data_engineering',
        'analytics': 'kw_analytics',
        'mlops': 'kw_mlops',
        'cloud': 'kw_cloud',
        'python': 'kw_python',
        'sql': 'kw_sql',
        'spark': 'kw_spark',
        'aws': 'kw_aws',
        'azure': 'kw_azure',
        'gcp': 'kw_gcp',
        'kubernetes': 'kw_kubernetes',
        'docker': 'kw_docker',
        'tableau': 'kw_tableau',
        'power bi': 'kw_power_bi',
        'looker': 'kw_looker',
        'dbt': 'kw_dbt',
        'airflow': 'kw_airflow',
        'kafka': 'kw_kafka',
        'snowflake': 'kw_snowflake',
        'security': 'kw_security',
        'compliance': 'kw_compliance',
        'architecture': 'kw_architecture',
        'research': 'kw_research',
    }
    for kw in title_keywords:
        col = kw_map.get(kw.lower())
        if col and col in feat:
            feat[col] = 1.0

    # Seniority title words
    seniority_map = {
        'senior': 'title_senior', 'lead': 'title_lead', 'principal': 'title_principal',
        'staff': 'title_staff', 'director': 'title_director', 'manager': 'title_manager',
        'associate': 'title_associate', 'junior': 'title_junior',
    }
    for word, col in seniority_map.items():
        if word in [k.lower() for k in title_keywords]:
            if col in feat:
                feat[col] = 1.0

    # Company type
    if company_type == 'FAANG / Big Tech':    feat['company_is_faang']       = 1.0
    if company_type == 'Consulting':           feat['company_is_consulting']   = 1.0
    if company_type == 'Finance / Banking':    feat['company_is_finance']      = 1.0

    vec = np.array([feat[n] for n in feature_names], dtype=np.float32).reshape(1, -1)
    return vec


def predict(
    job_level: str = 'Mid senior',
    job_type: str = 'Onsite',
    location: str = 'San Francisco, CA',
    title_keywords: list = None,
    company_type: str = 'Other',
    top_n: int = 3,
    models_dir: str = 'models',
    weights: dict = None,
) -> dict:
    """
    Run ensemble inference from job search criteria.
    Returns top-N job category predictions with confidence scores.
    """
    if title_keywords is None: title_keywords = []
    if weights is None: weights = {'lr': 0.2, 'xgb': 0.4, 'nn': 0.4}

    reg = get_registry(models_dir)

    X_raw    = encode_input(job_level, job_type, location, title_keywords,
                             company_type, reg.feature_names)
    X_scaled = reg.scaler.transform(X_raw)

    lr_p  = reg.lr.predict_proba(X_raw)[0]
    xgb_p = reg.xgb.predict_proba(X_raw)[0]
    nn_p  = reg.nn.predict(X_scaled, verbose=0)[0]

    ensemble = weights['lr'] * lr_p + weights['xgb'] * xgb_p + weights['nn'] * nn_p

    classes  = reg.encoder.classes_
    top_idx  = np.argsort(ensemble)[::-1][:top_n]

    recommendations = [
        {
            'rank': i + 1,
            'job': classes[idx],
            'confidence': round(float(ensemble[idx]), 4),
            'confidence_pct': round(float(ensemble[idx]) * 100, 1),
            'lr_confidence':  round(float(lr_p[idx])  * 100, 1),
            'xgb_confidence': round(float(xgb_p[idx]) * 100, 1),
            'nn_confidence':  round(float(nn_p[idx])  * 100, 1),
        }
        for i, idx in enumerate(top_idx)
    ]

    return {
        'top_recommendations': recommendations,
        'model_breakdown': {
            'lr_top':  classes[np.argmax(lr_p)],
            'xgb_top': classes[np.argmax(xgb_p)],
            'nn_top':  classes[np.argmax(nn_p)],
        },
        'all_scores': {
            classes[i]: round(float(ensemble[i]) * 100, 2)
            for i in np.argsort(ensemble)[::-1]
        },
        'input': {
            'job_level': job_level, 'job_type': job_type,
            'location': location, 'keywords': title_keywords,
            'company_type': company_type,
        },
    }
