"""
NLP Module: TF-IDF Job Title Similarity Search
================================================
For the real dataset, we use TF-IDF on job titles to enable
free-text job search — a user can type any job title fragment
and get the nearest matching categories.

This is the "search" layer; the ML models are the "classify" layer.
Together they cover both cold-start (text search) and trained inference.
"""

import os
import pickle

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


class JobTitleMatcher:
    """
    TF-IDF cosine similarity matcher over real job titles.
    Allows fuzzy free-text matching: "machine learning" → top matching categories.
    """

    def __init__(self):
        self.vectorizer = TfidfVectorizer(
            ngram_range=(1, 3),
            sublinear_tf=True,
            min_df=1,
            analyzer='word',
            stop_words='english',
        )
        self.title_vectors = None
        self.titles = None
        self.categories = None
        self.is_fitted = False

    def fit(self, titles: list[str], categories: list[str]):
        self.titles = titles
        self.categories = categories
        self.title_vectors = self.vectorizer.fit_transform(titles)
        self.is_fitted = True
        print(f'✅ TF-IDF fitted on {len(titles)} job titles | Vocab: {len(self.vectorizer.vocabulary_)}')
        return self

    def search(self, query: str, top_n: int = 5) -> list[dict]:
        """Find most similar job titles to a query string."""
        q_vec = self.vectorizer.transform([query.lower()])
        sims  = cosine_similarity(q_vec, self.title_vectors)[0]
        top_i = np.argsort(sims)[::-1][:top_n]
        return [
            {
                'title': self.titles[i],
                'category': self.categories[i],
                'similarity': round(float(sims[i]), 4),
            }
            for i in top_i if sims[i] > 0
        ]

    def top_categories_for_query(self, query: str, top_n: int = 3) -> list[dict]:
        """Aggregate similarity scores by category and return top categories."""
        matches = self.search(query, top_n=100)
        scores: dict[str, float] = {}
        counts: dict[str, int]   = {}
        for m in matches:
            cat = m['category']
            scores[cat] = scores.get(cat, 0) + m['similarity']
            counts[cat] = counts.get(cat, 0) + 1
        # Normalize by count to avoid over-weighting large categories
        avg = {cat: scores[cat] / counts[cat] for cat in scores}
        sorted_cats = sorted(avg.items(), key=lambda x: -x[1])[:top_n]
        total = sum(v for _, v in sorted_cats) or 1
        return [
            {
                'rank': i + 1,
                'category': cat,
                'similarity': round(score, 4),
                'confidence_pct': round(score / total * 100, 1),
            }
            for i, (cat, score) in enumerate(sorted_cats)
        ]

    def save(self, path: str):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'wb') as f:
            pickle.dump(self, f)
        print(f'💾 JobTitleMatcher saved: {path}')

    @staticmethod
    def load(path: str) -> 'JobTitleMatcher':
        with open(path, 'rb') as f:
            return pickle.load(f)


def build_title_matcher(
    csv_path: str = 'data/raw/job_postings.csv',
    save_path: str = 'models/artifacts/title_matcher.pkl',
) -> JobTitleMatcher:
    from data.process_dataset import categorize_title
    df = pd.read_csv(csv_path)
    df['category'] = df['job_title'].apply(categorize_title)
    df = df[df['category'].notna()].reset_index(drop=True)

    matcher = JobTitleMatcher()
    matcher.fit(df['job_title'].str.lower().tolist(), df['category'].tolist())
    matcher.save(save_path)
    return matcher


if __name__ == '__main__':
    m = build_title_matcher()
    for q in ['machine learning', 'data pipeline spark', 'cloud devops', 'nlp research']:
        print(f'\n🔍 "{q}":')
        for r in m.top_categories_for_query(q):
            print(f"   #{r['rank']} {r['category']:35s} {r['confidence_pct']}%")
