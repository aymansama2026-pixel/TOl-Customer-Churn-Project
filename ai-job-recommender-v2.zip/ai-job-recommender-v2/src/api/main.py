"""
FastAPI Backend — Job Postings Recommender
==========================================
"""

import json
import logging
import os
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, field_validator

logging.basicConfig(level=logging.INFO, format='%(asctime)s | %(levelname)s | %(message)s')
logger = logging.getLogger(__name__)

MODELS_DIR = os.getenv('MODELS_DIR', 'models')


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info('🚀 Warming up models...')
    try:
        from src.inference import get_registry
        reg = get_registry(MODELS_DIR)
        _ = reg.feature_names
        _ = reg.encoder
        logger.info(f'✅ Models ready | {len(reg.feature_names)} features | {len(reg.encoder.classes_)} classes')
    except Exception as e:
        logger.warning(f'⚠️  Model warm-up skipped: {e}')
    yield


app = FastAPI(
    title='AI Job Recommender — LinkedIn Dataset',
    description='Predicts best-fit job categories from job search preferences using a 3-model ensemble.',
    version='2.0.0',
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_methods=['*'],
    allow_headers=['*'],
)


@app.middleware('http')
async def log_requests(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    ms = round((time.time() - start) * 1000, 1)
    logger.info(f'{request.method} {request.url.path} → {response.status_code} ({ms}ms)')
    return response


# ── Schemas ───────────────────────────────────────────────────────────────────

class RecommendRequest(BaseModel):
    job_level: str = 'Mid senior'       # 'Mid senior' | 'Associate'
    job_type: str = 'Onsite'            # 'Onsite' | 'Remote' | 'Hybrid'
    location: str = 'San Francisco, CA'
    title_keywords: list[str] = []
    company_type: str = 'Other'         # 'FAANG / Big Tech' | 'Consulting' | 'Finance / Banking' | 'Other'
    top_n: int = 3

    @field_validator('job_level')
    @classmethod
    def validate_level(cls, v):
        if v not in ['Mid senior', 'Associate']:
            raise ValueError("job_level must be 'Mid senior' or 'Associate'")
        return v

    @field_validator('top_n')
    @classmethod
    def validate_top_n(cls, v):
        if not (1 <= v <= 12): raise ValueError('top_n must be 1–12')
        return v

    model_config = {'json_schema_extra': {'example': {
        'job_level': 'Mid senior',
        'job_type': 'Remote',
        'location': 'San Francisco, CA',
        'title_keywords': ['machine learning', 'python', 'deep learning'],
        'company_type': 'FAANG / Big Tech',
        'top_n': 3,
    }}}


# ── Endpoints ─────────────────────────────────────────────────────────────────

@app.get('/health', tags=['System'])
async def health():
    return {'status': 'healthy', 'version': '2.0.0', 'dataset': 'LinkedIn job_postings.csv'}


@app.post('/recommend', tags=['Inference'])
async def recommend(req: RecommendRequest):
    try:
        from src.inference import predict
        return predict(
            job_level=req.job_level,
            job_type=req.job_type,
            location=req.location,
            title_keywords=req.title_keywords,
            company_type=req.company_type,
            top_n=req.top_n,
            models_dir=MODELS_DIR,
        )
    except FileNotFoundError:
        raise HTTPException(503, detail='Models not found. Run: python scripts/train.py')
    except Exception as e:
        logger.error(f'Inference error: {e}', exc_info=True)
        raise HTTPException(500, detail=str(e))


@app.get('/feature-importance', tags=['Meta'])
async def feature_importance(top_n: int = 25):
    path = f'{MODELS_DIR}/artifacts/feature_importance.json'
    if not os.path.exists(path):
        raise HTTPException(404, 'Run training first')
    with open(path) as f:
        fi = json.load(f)
    return {
        'pairs': [{'feature': f, 'importance': round(i, 6)}
                  for f, i in zip(fi['features'][:top_n], fi['importances'][:top_n])]
    }


@app.get('/jobs', tags=['Meta'])
async def list_jobs():
    try:
        from src.inference import get_registry
        reg = get_registry(MODELS_DIR)
        return {'jobs': list(reg.encoder.classes_), 'count': len(reg.encoder.classes_)}
    except Exception as e:
        raise HTTPException(503, str(e))


@app.get('/dataset-stats', tags=['Meta'])
async def dataset_stats():
    """Return stats about the training dataset."""
    meta_path = 'data/processed/metadata.json'
    if not os.path.exists(meta_path):
        raise HTTPException(404, 'Run data processing first')
    with open(meta_path) as f:
        return json.load(f)


if __name__ == '__main__':
    import uvicorn
    uvicorn.run('src.api.main:app', host='0.0.0.0', port=8000, reload=True)
